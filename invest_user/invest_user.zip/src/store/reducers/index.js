import { combineReducers } from 'redux';
const reducers = combineReducers({
});

export default reducers; 
